# PHP Crash Course Files

These are the files from my crash course on Youtube. If you want to follow along and use the files, you can clone or download the zip and use the **_starter_files** folder.

If you are using VS Code and prettier and want Prettier to work with .php files, run

```
npm install
```